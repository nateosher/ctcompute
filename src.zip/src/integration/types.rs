//----------------------------------------
// integration mod types
//----------------------------------------
#[derive(PartialEq, Clone, Copy)]
pub enum IntegralType {
    Upper,
    Lower,
}
